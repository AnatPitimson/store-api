package webapi.restapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapplicationApplication.class, args);
	}

}
