package webapi.restapplication;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

/*
@RestController annotation indicates that every method in this
class will return actual values and not a view that a user's browser
should render
 */
@RestController
public class ProductController {
    private final ProductRepo productRepo;

    public ProductController(ProductRepo productRepo){
        this.productRepo = productRepo;
    }

    /**
     * This is an RPC controller method.
     * A component in Spring called Jackson converts
     * the List<Product> to their representation in a JSON format
     * this method returns an array of JSON objects, each inner
     * JSON represents a single product
     * Jackson executes deserialization
     * @return
     */

    // Data Transfer Object - DTO
    @GetMapping("/products/{id}")
    EntityModel<Product> getSingleProduct(@PathVariable Long id){
        Product product = productRepo.findById(id).orElseThrow(()->
                new ProductNotFoundException(id));
        return EntityModel.of(product,
                /*
                SelfRel is useful when the access to a resource may be done by various identifiers,
                for example when a route includes request parameters.
                localhost:8080/products/3?field="productCategory" will only show a json with
                the product's category. How can a user save on a database the full representation of the object?
                using as selfrel href.
                 */
                linkTo(methodOn(ProductController.class).getSingleProduct(id)).withSelfRel(),
                linkTo(methodOn(ProductController.class).getAllProducts()).withRel("back to all products"));
    }

    // Data Access Object (DAO)
//    @GetMapping("/products")
//        List<Product> getAllProducts(){
//        return this.productRepo.findAll();
//    }

    @GetMapping("/products")
    CollectionModel<EntityModel<Product>> getAllProducts(){
        List<Product> productList = productRepo.findAll();
        /*
        solution:
            1. take each Product and convert it to a EntityModel<Product>
            output from phase 1 = List<EntityModel<Product>> entityList
            2. If List is Java type -> Jackson will implicitly deserialize the list
            We will use a container of containers called CollectionModel
            3. we can even add links to the outer container
         */
       List<EntityModel<Product>> entityList  = productList.stream().map(product->EntityModel.of(product,
                linkTo(methodOn(ProductController.class).getSingleProduct(product.getId())).withSelfRel(),
                linkTo(methodOn(ProductController.class).getAllProducts()).withRel("back to all products")))
                .collect(Collectors.toList());
        return CollectionModel.of(entityList,linkTo(methodOn(ProductController.class)
                .getAllProducts()).withSelfRel());
    }


    @GetMapping("/getproduct")
    Product getProductParam(@RequestParam (required = true) Long id){
        return productRepo.findById(id)
                .orElseThrow(()->new ProductNotFoundException(id));    }

//    @GetMapping("/products/{id}")
//    Product getSingleProduct(@PathVariable Long id){
//        return productRepo.findById(id)
//                .orElseThrow(()->new ProductNotFoundException(id));
//    }

    /*
    Instead of relying on Jackson to return the representation of the object,
    use a special container and add links to it
     */





//    @GetMapping("/productscategory")
//    List<Product> getProductsByCategory(@RequestParam (required = false) String category){
//        if (category!=null){
//            return productRepo.getProductsByCategory(category);
//        }
//        else return getAllProducts();
//    }

    @GetMapping("/productscategory/{category}")
    List<Product> getProductsByCategory2(@PathVariable String category){
            return productRepo.getProductsByCategory(category);
    }

    /*
    Jackson executes serialization - takes a representation of the Product
    and convert it to an actual Java object
     */
    @PostMapping("/products")
    Product createProduct(@RequestBody Product newProduct) {
        if (newProduct.getId() != null) {
            return productRepo.findById(newProduct.getId())
                    .orElseGet(()-> productRepo.save(newProduct));
        }
        return productRepo.save(newProduct);
    }


    @PutMapping("/products/{id}")
    Product updateProduct(@PathVariable Long id, @RequestBody Product newProduct) {
        return productRepo.findById(id)
                // convert row in table to Java object
                .map(productToUpdate -> {
                    productToUpdate.setProductName(newProduct.getProductName());
                    productToUpdate.setPrice(newProduct.getPrice());
                    productToUpdate.setCategory(newProduct.getCategory());
                    // save Java object to row in an SQL table
                    return productRepo.save(productToUpdate);
                }).orElseGet(() -> {
                    return createProduct(newProduct);
                });
    }

    /*
    There are 2 paradigms for API URL formation:
    for a specific resource, we can either use:
    1. Path variable
    2. Request parameter
     */
}
