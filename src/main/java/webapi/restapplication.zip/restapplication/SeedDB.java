package webapi.restapplication;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.swing.*;

/**
 * Seeder class - initializes the DB in startup, enables developers to work with
 * real data before users can actually use the API
 */
@Configuration
public class SeedDB {
    private static final Logger logger = LoggerFactory.getLogger(SeedDB.class);
    /*
    Bean objects are in the core of the Spring framework (IoC Container)
    bean objects are instantiated, managed and destroyed by the IoC Container
     */
    @Bean
    CommandLineRunner seedDatabase(ProductRepo myProducts){
        return args -> {
            logger.info("logging" +
                    myProducts.save(new Product("AirPods v3 2021","Headphones",250.0)));
            logger.info("logging" +
                    myProducts.save(new Product("iPhone 13","Cellphones",1000)));
            logger.info("logging" +
                    myProducts.save(new Product("Macbook Pro 13 2021","Laptops" +
                            "",1500)));
            logger.info("logging" +
                    myProducts.save(new Product("Samsung Galaxy 22","Cellphones",1500)));
            logger.info("logging" +
                    myProducts.save(new Product("Boeing Secure","Cellphones",2500)));
        };
    }
}
