package webapi.restapplication;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/**
 * JpaRepository is DAL interface
 */
public interface ProductRepo extends JpaRepository<Product,Long> {
    /*
    Spring Data-> JPA (Java Persist Access)-> Hibernate -> JDBC driver
     */
    List<Product> getProductsByCategory(String category);
    /*
     IoC - inversion of control. declare what you want to do,
     Spring will implement it for you
     */
    List<Product> getProductsByProductName(String name);

}
