package webapi.restapplication;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
@NoArgsConstructor
public class Product {
    private @Id @GeneratedValue Long id;
    private String productName;
    private String category;
    private double price;
    private Integer amount;


    public Product(String productName, String category, double price){
        this.productName = productName;
        this.category = category;
        this.price = price;
    }



}
